package com.example.project4_codemath

import org.junit.Test

import org.junit.Assert.*

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    fun calculateDogYears_isCorrect() {
        val calculator = DogAgeCalculator()
        val humanYears = 5
        val expectedDogYears = 35
        val result = calculator.calculateDogYears(humanYears)
        assertEquals(expectedDogYears, result)
    }
}