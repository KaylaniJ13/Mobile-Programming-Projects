package com.example.project4_codemath

class DogAgeCalculator {
    fun calculateDogYears(humanYears: Int): Int {
        return humanYears * 7
    }
}