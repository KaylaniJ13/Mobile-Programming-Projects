package com.example.project4_codemath

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DogAgeCalculatorScreen()
                }
            }
        }
    }
}

@Composable
fun DogAgeCalculatorScreen() {
    var humanYearsInput by remember { mutableStateOf("") }
    var dogYearsResult by remember { mutableStateOf<Int?>(null) }
    val calculator = remember { DogAgeCalculator() }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Text(
            text = stringResource(R.string.header_text),
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier.padding(top = 40.dp)
        )

        Spacer(modifier = Modifier.height(40.dp))

        // Input
        TextField(
            value = humanYearsInput,
            onValueChange = { humanYearsInput = it },
            label = { Text(stringResource(R.string.hint_human_years)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Button
        Button(
            onClick = {
                if (humanYearsInput.isEmpty()) {
                    Toast.makeText(context, R.string.error_empty_input, Toast.LENGTH_SHORT).show()
                } else {
                    val humanYears = humanYearsInput.toIntOrNull()
                    if (humanYears != null) {
                        dogYearsResult = calculator.calculateDogYears(humanYears)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = stringResource(R.string.button_calculate),
                fontSize = 18.sp
            )
        }

        Spacer(modifier = Modifier.height(40.dp))

        // Result
        if (dogYearsResult != null) {
            Text(
                text = stringResource(R.string.result_dog_age, dogYearsResult!!),
                fontSize = 24.sp,
                color = Color(0xFF4CAF50),
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun DogAgeCalculatorPreview() {
    MaterialTheme {
        DogAgeCalculatorScreen()
    }
}