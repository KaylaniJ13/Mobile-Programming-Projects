package com.driuft.androidkotlindebugging.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.driuft.androidkotlindebugging.R

class PrintListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_print_list)

        // 1. Find the TextView defined in your XML
        val textView = findViewById<TextView>(R.id.word_list)

        // 2. Create your list of words
        val myWords = listOf("Apple", "Banana", "Cherry", "Date", "Elderberry")

        // 3. Join the words into one string, separated by a "new line" (\n)
        // This turns the list into:
        // Apple
        // Banana
        // Cherry...
        val formattedString = myWords.joinToString("\n")

        // 4. Set the text
        textView.text = formattedString
    }
}