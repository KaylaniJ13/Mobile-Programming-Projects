package com.driuft.androidkotlindebugging.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.driuft.androidkotlindebugging.R

class NumSumActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_num_sum)

        val resultText = findViewById<TextView>(R.id.result_text)
        val num1 = 8
        val num2 = 2
        val sum = num1 + num2

        // FIX: Use getString with the resource ID and pass the numbers as arguments
        // This fills in the %1$d, %2$d, and %3$d placeholders defined in XML
        resultText.text = getString(R.string.sum_result, num1, num2, sum)
    }
}