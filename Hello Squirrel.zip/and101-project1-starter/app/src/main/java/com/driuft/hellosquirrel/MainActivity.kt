package com.driuft.hellosquirrel

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var profileName: TextView
    private lateinit var profileBio: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        configureViews()
        setupProfile()
    }

    private fun configureViews() {
        // profileImage is defined in XML, we don't need to modify it here anymore
        profileName = findViewById(R.id.profile_name)
        profileBio = findViewById(R.id.profile_bio)
    }

    private fun setupProfile() {
        configureName()
    }

    private fun configureName() {
        profileName.text = getString(
            R.string.full_name,
            getString(R.string.first_name),
            getString(R.string.last_name)
        )
    }
}