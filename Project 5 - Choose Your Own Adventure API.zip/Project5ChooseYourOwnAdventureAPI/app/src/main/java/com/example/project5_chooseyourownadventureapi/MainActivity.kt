package com.example.project5_chooseyourownadventureapi

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.viewinterop.AndroidViewBinding
import com.bumptech.glide.Glide
import com.codepath.asynchttpclient.AsyncHttpClient
import com.codepath.asynchttpclient.callback.JsonHttpResponseHandler
import com.example.project5_chooseyourownadventureapi.databinding.ActivityMainBinding
import okhttp3.Headers
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    var pokeImageUrl = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.btn_random)
        val imageView = findViewById<ImageView>(R.id.poke_image)
        val nameText = findViewById<TextView>(R.id.poke_name)
        val idText = findViewById<TextView>(R.id.poke_id)
        val weightText = findViewById<TextView>(R.id.poke_weight)

        // Load a Pokemon as soon as the app starts
        getPokemon(imageView, nameText, idText, weightText)

        // Load a new one when button is clicked
        button.setOnClickListener {
            getPokemon(imageView, nameText, idText, weightText)
        }
    }

    private fun getPokemon(view: ImageView, nameTv: TextView, idTv: TextView, weightTv: TextView) {
        val client = AsyncHttpClient()

        // 1. Generate Random ID (1 to 898 are valid classic pokemon)
        val randomId = Random.nextInt(1, 899)
        val url = "https://pokeapi.co/api/v2/pokemon/$randomId"

        client.get(url, object : JsonHttpResponseHandler() {
            override fun onSuccess(statusCode: Int, headers: Headers, json: JSON) {
                Log.d("Pokemon", "Response successful")

                // 2. Access the JSON object
                val jsonObject = json.jsonObject

                // 3. Parse the data we want
                val name = jsonObject.getString("name")
                val id = jsonObject.getInt("id")
                val weight = jsonObject.getInt("weight")

                // For the image, we have to go deeper into the JSON: sprites -> front_default
                val sprites = jsonObject.getJSONObject("sprites")
                pokeImageUrl = sprites.getString("front_default")

                // 4. Update the UI
                // Using runOnUiThread is good practice, though AsyncHttpClient handles it mostly
                runOnUiThread {
                    nameTv.text = name
                    idTv.text = getString(R.string.pokemon_id_format, id)
                    weightTv.text = getString(R.string.pokemon_weight_format, weight)

                    // Use Glide to load the image from the URL
                    Glide.with(this@MainActivity)
                        .load(pokeImageUrl)
                        .fitCenter()
                        .into(view)
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Headers?,
                response: String,
                throwable: Throwable?
            ) {
                Log.d("Pokemon", "Error: $response")
            }
        })
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    val context = LocalContext.current
    AndroidViewBinding(ActivityMainBinding::inflate) {
        btnRandom.setOnClickListener {
            val client = AsyncHttpClient()
            val randomId = Random.nextInt(1, 899)
            val url = "https://pokeapi.co/api/v2/pokemon/$randomId"

            client.get(url, object : JsonHttpResponseHandler() {
                override fun onSuccess(statusCode: Int, headers: Headers, json: JSON) {
                    val jsonObject = json.jsonObject
                    val name = jsonObject.getString("name")
                    val id = jsonObject.getInt("id")
                    val weight = jsonObject.getInt("weight")
                    val sprites = jsonObject.getJSONObject("sprites")
                    val pokeImageUrl = sprites.getString("front_default")

                    pokeName.text = name
                    pokeId.text = context.getString(R.string.pokemon_id_format, id)
                    pokeWeight.text = context.getString(R.string.pokemon_weight_format, weight)

                    Glide.with(context)
                        .load(pokeImageUrl)
                        .fitCenter()
                        .into(pokeImage)
                }

                override fun onFailure(
                    statusCode: Int,
                    headers: Headers?,
                    response: String,
                    throwable: Throwable?
                ) {
                    Log.e("PokemonPreview", "Error: $response")
                }
            })
        }
    }
}
